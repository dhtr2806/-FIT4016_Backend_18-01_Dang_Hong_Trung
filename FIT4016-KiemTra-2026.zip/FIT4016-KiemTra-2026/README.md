# School Management System

This project is built using C# and Entity Framework Core.

## Features
- Manage Schools and Students
- CRUD operations for Students
- Pagination
- Data validation
- Clean and readable code

## Technologies
- .NET
- Entity Framework Core
- SQL Server
