using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SchoolManagement
{
    public class SchoolDbContext : DbContext
    {
        public DbSet<School> Schools { get; set; }
        public DbSet<Student> Students { get; set; }

      
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // CHANGE THIS to your actual Server Name
            optionsBuilder.UseSqlServer( "Server=(localdb)\\MSSQLLocalDB;Database=SchoolManagement;Trusted_Connection=True;TrustServerCertificate=True;"
);
        }

        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Unique constraints
            modelBuilder.Entity<School>()
                .HasIndex(s => s.Name)
                .IsUnique();

            modelBuilder.Entity<Student>()
                .HasIndex(s => s.StudentId)
                .IsUnique();

            modelBuilder.Entity<Student>()
                .HasIndex(s => s.Email)
                .IsUnique();
        }

        
        public void SeedData()
        {
            if (!Schools.Any())
            {
                var schools = new List<School>();
                for (int i = 1; i <= 10; i++)
                {
                    schools.Add(new School
                    {
                        Name = $"High School {i}",
                        Principal = $"Principal {i}",
                        Address = $"Address {i} Street",
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    });
                }
                Schools.AddRange(schools);
                SaveChanges();
            }

            if (!Students.Any())
            {
                var schoolIds = Schools.Select(s => s.Id).ToList();
                var students = new List<Student>();
                var random = new Random();

                for (int i = 1; i <= 20; i++)
                {
                    students.Add(new Student
                    {
                        FullName = $"Student Name {i}",
                        StudentId = $"STU{i:D5}", // Format STU00001
                        Email = $"student{i}@school.com",
                        Phone = $"0901234{i:D3}",
                        SchoolId = schoolIds[random.Next(schoolIds.Count)],
                        CreatedAt = DateTime.Now,
                        UpdatedAt = DateTime.Now
                    });
                }
                Students.AddRange(students);
                SaveChanges();
            }
        }
    }
}