using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagement
{
    // School entity definition
    public class School
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } // Configured as Unique in DbContext

        [Required]
        public string Principal { get; set; }

        [Required]
        public string Address { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        // User-friendly error message
        public ICollection<Student> Students { get; set; } = new List<Student>();
    }
}