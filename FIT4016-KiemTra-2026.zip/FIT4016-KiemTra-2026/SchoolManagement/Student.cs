using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagement
{
    // Student entity definition
    public class Student
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [ForeignKey("School")]
        public int SchoolId { get; set; }

        [Required]
    [StringLength(100, MinimumLength = 2)] // Full name: 2-100 chars [cite: 26]
        public string FullName { get; set; }

        [Required]
        [StringLength(20, MinimumLength = 5)] // Student ID: 5-20 chars [cite: 27]
        public string StudentId { get; set; }

        [Required]
      [EmailAddress] // Basic email format validation [cite: 28]
        public string Email { get; set; }

       // Phone is nullable, validation logic will be in Service [cite: 29]
        public string? Phone { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        // Navigation property
        public School School { get; set; }
    }
}