using System;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;

namespace SchoolManagement
{
    public class StudentService
    {
        private readonly SchoolDbContext _context;

        public StudentService(SchoolDbContext context)
        {
            _context = context;
        }

        // CREATE
        public void CreateStudent(Student student)
        {
            if (!ValidateStudent(student)) return;

            _context.Students.Add(student);
            _context.SaveChanges();
        }

        // READ (Pagination)
        public void ListStudents(int page = 1)
        {
            var students = _context.Students
                .Include(s => s.School)
                .Skip((page - 1) * 10)
                .Take(10)
                .ToList();

            foreach (var s in students)
            {
                Console.WriteLine($"{s.Id} | {s.FullName} | {s.StudentId} | {s.Email}");
            }
        }

        // UPDATE
        public void UpdateStudent(int id, Student updated)
        {
            var student = _context.Students.Find(id);
            if (student == null) return;

            if (!ValidateStudent(updated, id)) return;

            student.FullName = updated.FullName;
            student.StudentId = updated.StudentId;
            student.Email = updated.Email;
            student.Phone = updated.Phone;
            student.SchoolId = updated.SchoolId;

            _context.SaveChanges();
        }

        // DELETE
        public void DeleteStudent(int id)
        {
            var student = _context.Students.Find(id);
            if (student == null) return;

            _context.Students.Remove(student);
            _context.SaveChanges();
        }

        // VALIDATION
        private bool ValidateStudent(Student student, int? id = null)
        {
            if (string.IsNullOrWhiteSpace(student.FullName) || student.FullName.Length < 2)
                return false;

            if (_context.Students.Any(s => s.StudentId == student.StudentId && s.Id != id))
                return false;

            if (_context.Students.Any(s => s.Email == student.Email && s.Id != id))
                return false;

            if (!string.IsNullOrEmpty(student.Phone) &&
                !Regex.IsMatch(student.Phone, @"^\d{10,11}$"))
                return false;

            if (!_context.Schools.Any(s => s.Id == student.SchoolId))
                return false;

            return true;
        }
    }
}
