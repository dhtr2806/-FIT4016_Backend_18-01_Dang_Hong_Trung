using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace SchoolManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize Database and Seed Data
            using (var context = new SchoolDbContext())
            {
                // Ensure database is created (Code First)
                context.Database.EnsureCreated();
                context.SeedData();
            }

            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== SCHOOL MANAGEMENT SYSTEM ===");
                Console.WriteLine("1. Create new student");
                Console.WriteLine("2. Read student list (Pagination)");
                Console.WriteLine("3. Update student");
                Console.WriteLine("4. Delete student");
                Console.WriteLine("5. Exit");
                Console.Write("Select option: ");
                
                var choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1": CreateStudent(); break;
                        case "2": ReadStudents(); break;
                        case "3": UpdateStudent(); break;
                        case "4": DeleteStudent(); break;
                        case "5": return;
                        default: Console.WriteLine("Invalid option!"); break;
                    }
                }
                catch (Exception ex)
                {
                    // User-friendly error message
                Console.WriteLine($"An error occurred: {ex.Message}");

                }

                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
            }
        }

        // User-friendly error message
        static void CreateStudent()
        {
            Console.WriteLine("\n--- Create New Student ---");
            using (var context = new SchoolDbContext())
            {
                string fullName = GetInput("Full Name (2-100 chars): ");
               // User-friendly error message
                if (fullName.Length < 2 || fullName.Length > 100) 
                    throw new Exception("Full name must be between 2 and 100 characters.");

                string studentId = GetInput("Student ID (5-20 chars, unique): ");
                // User-friendly error message
                if (studentId.Length < 5 || studentId.Length > 20)
                    throw new Exception("Student ID must be between 5 and 20 characters.");
                if (context.Students.Any(s => s.StudentId == studentId))
                    throw new Exception("Student ID already exists.");

                string email = GetInput("Email: ");
                // User-friendly error message
                if (!IsValidEmail(email)) throw new Exception("Invalid email format.");
                if (context.Students.Any(s => s.Email == email))
                    throw new Exception("Email already exists.");

                string phone = GetInput("Phone (Optional, enter to skip): ");
               // User-friendly error message
                if (!string.IsNullOrEmpty(phone) && !Regex.IsMatch(phone, @"^\d{10,11}$"))
                    throw new Exception("Phone must be 10-11 digits.");

                Console.WriteLine("Available Schools:");
                foreach(var s in context.Schools) Console.WriteLine($"ID: {s.Id} - {s.Name}");
                
                if (!int.TryParse(GetInput("School ID: "), out int schoolId))
                    throw new Exception("Invalid School ID format.");
                
               // User-friendly error message
                if (!context.Schools.Any(s => s.Id == schoolId))
                    throw new Exception("School does not exist.");

                var newStudent = new Student
                {
                    FullName = fullName,
                    StudentId = studentId,
                    Email = email,
                    Phone = string.IsNullOrEmpty(phone) ? null : phone,
                    SchoolId = schoolId,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                context.Students.Add(newStudent);
                context.SaveChanges();
                Console.WriteLine("Student created successfully!");
            }
        }

       // User-friendly error message
        static void ReadStudents()
        {
            Console.WriteLine("\n--- Student List ---");
            using (var context = new SchoolDbContext())
            {
                int pageSize = 10; // [cite: 37]
                int pageNumber = 1;
                int totalStudents = context.Students.Count();
                int totalPages = (int)Math.Ceiling((double)totalStudents / pageSize);

                while (true)
                {
                    Console.WriteLine($"\nPage {pageNumber}/{totalPages}");
                    Console.WriteLine(new string('-', 85));
                    Console.WriteLine($"| {"ID",-5} | {"Full Name",-20} | {"Student ID",-10} | {"Email",-20} | {"School",-15} |");
                    Console.WriteLine(new string('-', 85));

                    // User-friendly error message
                    var students = context.Students
                        .Include(s => s.School)
                        .OrderBy(s => s.Id)
                        .Skip((pageNumber - 1) * pageSize)
                        .Take(pageSize)
                        .ToList();

                    foreach (var s in students)
                    {
                        Console.WriteLine($"| {s.Id,-5} | {s.FullName,-20} | {s.StudentId,-10} | {s.Email,-20} | {s.School.Name,-15} |");
                    }

                    Console.WriteLine("\nN: Next Page | P: Previous Page | X: Exit View");
                    var key = Console.ReadKey(true).Key;

                    if (key == ConsoleKey.N && pageNumber < totalPages) pageNumber++;
                    else if (key == ConsoleKey.P && pageNumber > 1) pageNumber--;
                    else if (key == ConsoleKey.X) break;
                }
            }
        }

        // User-friendly error message
        static void UpdateStudent()
        {
            Console.WriteLine("\n--- Update Student ---");
            using (var context = new SchoolDbContext())
            {
                Console.Write("Enter Student ID (Database ID) to update: ");
                if (!int.TryParse(Console.ReadLine(), out int id)) return;

                var student = context.Students.Find(id);
                if (student == null) throw new Exception("Student not found.");

               // User-friendly error message
                Console.WriteLine($"Editing: {student.FullName} (Current Email: {student.Email})");
                Console.WriteLine("Leave blank to keep current value.");

                // Update Full Name
                string name = GetInput("New Full Name: ");
                if (!string.IsNullOrEmpty(name))
                {
                    if (name.Length < 2 || name.Length > 100) throw new Exception("Invalid name length.");
                    student.FullName = name;
                }

                // Update Email
                string email = GetInput("New Email: ");
                if (!string.IsNullOrEmpty(email))
                {
                    if (!IsValidEmail(email)) throw new Exception("Invalid email format.");
                    // Check duplicate if email changed
                    if (email != student.Email && context.Students.Any(s => s.Email == email))
                        throw new Exception("Email already taken.");
                    student.Email = email;
                }

                // Update Phone
                string phone = GetInput("New Phone: ");
                if (!string.IsNullOrEmpty(phone))
                {
                    if (!Regex.IsMatch(phone, @"^\d{10,11}$")) throw new Exception("Invalid phone format.");
                    student.Phone = phone;
                }

                // Update School
                string schoolIdStr = GetInput("New School ID: ");
                if (!string.IsNullOrEmpty(schoolIdStr))
                {
                    if (int.TryParse(schoolIdStr, out int schoolId))
                    {
                        if (!context.Schools.Any(s => s.Id == schoolId)) throw new Exception("School not found.");
                        student.SchoolId = schoolId;
                    }
                }

                student.UpdatedAt = DateTime.Now;
                context.SaveChanges();
                Console.WriteLine("Student updated successfully! [cite: 53]");
            }
        }

      
        static void DeleteStudent()
        {
            Console.WriteLine("\n--- Delete Student ---");
            using (var context = new SchoolDbContext())
            {
                Console.Write("Enter Student ID to delete: ");
                if (!int.TryParse(Console.ReadLine(), out int id)) return;

                var student = context.Students.Find(id);
                if (student == null) throw new Exception("Student not found.");

               
                Console.Write($"Are you sure you want to delete {student.FullName}? (y/n): ");
                if (Console.ReadLine()?.ToLower() == "y")
                {
                    context.Students.Remove(student);
                    context.SaveChanges();
                    Console.WriteLine("Student deleted successfully.");
                }
                else
                {
                    Console.WriteLine("Operation cancelled.");
                }
            }
        }

        // Helper methods
        static string GetInput(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine()?.Trim();
        }

        static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
    }
}
// context.SeedData();
